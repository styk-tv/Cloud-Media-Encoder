
class Config:
    ROOTDIR="."
    CONFIGDIR="./etc"
    QUEUEDIR="./queue"
    STORES_ROOT="./volumes"
