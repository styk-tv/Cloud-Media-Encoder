
class Config:
    ROOTDIR="/opt/node"
    CONFIGDIR="/opt/node/etc"
    QUEUEDIR="/opt/node/queue"
    STORES_ROOT="/var/www/volumes"
